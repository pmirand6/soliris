create
    definer = soliris_ap@`%` procedure ST_LIST_ESTADOS_PACIENTE() comment 'LISTA LOS ESTADO DEL PACIENTE'
BEGIN

SELECT id, valor FROM maestro_estado e WHERE e.referencia = 'paciente' AND e.tipo = 'estado';

END;

