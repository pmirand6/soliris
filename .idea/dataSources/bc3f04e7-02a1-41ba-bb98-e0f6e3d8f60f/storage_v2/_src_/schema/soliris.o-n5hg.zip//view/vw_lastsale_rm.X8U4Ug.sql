create definer = root@localhost view vw_lastsale_rm as
select `RM`.`paciente_id`                                                                AS `pid`,
       (select concat(`p`.`apellido`, ' ,', `p`.`nombre`) from `soliris`.`paciente` `p`) AS `nombre`,
       date_format(`RM`.`fecha_venta`, '%d/%m/%y')                                       AS `fventa`
from `soliris`.`soliris_maestro` `RM`
where (`RM`.`estado_venta_id` <> 14)
group by (select concat(`p`.`apellido`, ' ,', `p`.`nombre`) from `soliris`.`paciente` `p`)
order by `RM`.`id` desc;

