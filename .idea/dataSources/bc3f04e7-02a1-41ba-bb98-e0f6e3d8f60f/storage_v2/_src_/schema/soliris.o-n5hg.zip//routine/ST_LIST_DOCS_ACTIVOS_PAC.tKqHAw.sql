create
    definer = soliris_ap@`%` procedure ST_LIST_DOCS_ACTIVOS_PAC(IN v_id int) comment 'Lista los documentos del paciente'
BEGIN

SELECT 
	d.valor AS documento, 
	dt.tipo
FROM documentos as d
LEFT OUTER JOIN documentos_tipo as dt ON d.documentos_tipo_id = dt.id
INNER JOIN rel_paciente_documentos rel ON d.id = rel.documento_id
WHERE rel.paciente_id = 4 AND d.estado_id = 15
GROUP BY d.valor, dt.tipo ORDER BY d.id;

END;

