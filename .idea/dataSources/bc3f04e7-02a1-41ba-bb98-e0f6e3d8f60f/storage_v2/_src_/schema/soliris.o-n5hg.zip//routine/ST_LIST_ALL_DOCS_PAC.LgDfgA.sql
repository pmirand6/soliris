create
    definer = soliris_ap@`%` procedure ST_LIST_ALL_DOCS_PAC(IN v_idPac int) comment 'Lista los documentos del paciente'
BEGIN

SELECT 
	dt.tipo,
	d.valor AS documento, 
	date_format(d.fecha_documento, '%d/%m/%Y') AS fecha_doc,
	m.valor AS estado
FROM documentos as d
LEFT OUTER JOIN documentos_tipo as dt ON d.documentos_tipo_id = dt.id
INNER JOIN rel_paciente_documentos rel ON d.id = rel.documento_id
INNER JOIN maestro_estado m ON m.id = d.estado_id
WHERE rel.paciente_id = v_idPac
GROUP BY d.valor, dt.tipo ORDER BY d.id desc;

END;

