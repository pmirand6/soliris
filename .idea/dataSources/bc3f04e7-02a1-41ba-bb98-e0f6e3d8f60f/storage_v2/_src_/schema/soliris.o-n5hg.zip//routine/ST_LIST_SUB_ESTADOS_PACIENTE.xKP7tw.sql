create
    definer = soliris_ap@`%` procedure ST_LIST_SUB_ESTADOS_PACIENTE() comment 'Lista los subestados del paciente'
BEGIN

SELECT id, valor FROM maestro_estado e WHERE e.referencia = 'paciente' AND e.tipo = 'sub_estado';

END;

