create
    definer = soliris_ap@`%` function FU_UP_CANAL(v_nombre varchar(100), v_familia varchar(45), v_direccion longtext,
                                                  v_mail varchar(200), v_dir_tec varchar(200), v_cont_venta longtext,
                                                  v_cont_otro longtext, v_puntos_entrega longtext, v_estado varchar(45),
                                                  v_usuario varchar(45), v_id int) returns longtext
BEGIN
DECLARE devolucion LONGTEXT;
		UPDATE canales SET 
			canal = v_nombre, 
			familia = v_familia, 
			direccion = v_direccion,
			mail = v_mail,
			dir_tec = v_dir_tec,
			cont_venta = v_cont_venta,
			cont_otro = v_cont_otro,
			puntos_entrega = v_puntos_entrega,
			estado = v_estado, 
			usuario_audit = v_usuario
		WHERE 
			id = v_id;

	IF (SELECT ROW_COUNT() > 0)  THEN
			SET devolucion = v_id;
	ELSE
			SET devolucion = 'ERROR NO_UPDATE';
	END IF;
	
	RETURN devolucion;

END;

