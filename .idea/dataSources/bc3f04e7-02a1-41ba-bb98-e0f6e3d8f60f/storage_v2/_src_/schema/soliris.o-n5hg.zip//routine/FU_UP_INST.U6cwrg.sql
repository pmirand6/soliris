create
    definer = soliris_ap@`%` function FU_UP_INST(v_nombre varchar(250), v_direccion varchar(250), v_altura int,
                                                 v_localidad varchar(100), v_provincia varchar(100),
                                                 v_contacto varchar(100), v_mail varchar(100), v_telefono varchar(45),
                                                 v_notas longtext, v_tipo varchar(10), v_estado varchar(45),
                                                 v_familia varchar(3), v_usuario varchar(45), v_id int) returns longtext
BEGIN
DECLARE devolucion LONGTEXT;
		UPDATE institucion SET 
			nombre = v_nombre, 
			direccion = v_direccion, 
			altura = v_altura, 
			localidad = v_localidad, 
			provincia = v_provincia, 
			contacto = v_contacto, 
			mail = v_mail, 
			telefono = v_telefono, 
			notas = v_notas, 
			tipo = v_tipo, 
			familia = v_familia, 
  		estado = v_estado, 
			usuario_audit = v_usuario
		WHERE 
			id = v_id;

	IF (SELECT ROW_COUNT() > 0)  THEN
			SET devolucion = v_id;
	ELSE
			SET devolucion = 'ERROR NO_UPDATE';
	END IF;
	
	RETURN devolucion;

END;

