create
    definer = soliris_ap@`%` procedure put_log(IN v_usuario varchar(50), IN v_id int, IN v_tabla varchar(50),
                                               IN v_notas longtext) comment 'Carga informacion al log de la app'
BEGIN

declare d_values longtext;

set d_values=(SELECT group_concat(column_name) FROM information_schema.COLUMNS where TABLE_SCHEMA='soliris' and TABLE_NAME=v_tabla);



insert into soliris_log (usuario,fecha, accion, registro, tabla, notas) (select d_values from v_tabla where id=v_id) ;


END;

