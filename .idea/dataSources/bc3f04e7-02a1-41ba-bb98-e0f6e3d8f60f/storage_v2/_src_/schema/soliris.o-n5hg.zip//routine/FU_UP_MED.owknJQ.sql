create
    definer = soliris_ap@`%` function FU_UP_MED(v_nombre varchar(200), v_matricula_tipo varchar(45),
                                                v_matricula_numero varchar(45), v_Lugar varchar(45),
                                                v_C_Atencion varchar(255), v_telefono varchar(45), v_Fax varchar(45),
                                                v_nacimiento varchar(20), v_domicilio varchar(255),
                                                v_localidad varchar(255), v_fecha_cap varchar(20),
                                                v_especialidad varchar(255), v_apm int, v_estado varchar(15),
                                                v_usuario varchar(45), v_id int, v_email varchar(255)) returns longtext
BEGIN
DECLARE devolucion LONGTEXT;
	IF v_estado = 'Activo' THEN
		UPDATE medicos SET 
			Aprobado = v_usuario,
			Fecha_Aprobado = now()
		WHERE 
			id = v_id;
	END IF;

		UPDATE medicos SET 
				Nombre = v_nombre,
		    matricula_tipo = v_matricula_tipo,
		    matricula_numero = v_matricula_numero,
		    Lugar = v_Lugar,
		    C_Atencion = v_C_Atencion,
		    telefono = v_telefono,
		    Fax = v_Fax,
		    nacimiento = v_nacimiento,
		    domicilio = v_domicilio,
		    localidad = v_localidad,
		    fecha_cap = v_fecha_cap,
		    especialidad = v_especialidad,
		    apm = v_apm,
		    estado = v_estado,
  		    mail = v_email
		WHERE 
			id = v_id;

	

	IF (SELECT ROW_COUNT() > 0)  THEN
			SET devolucion = v_id;
	ELSE
			SET devolucion = 'ERROR NO_UPDATE';
	END IF;
	
	RETURN devolucion;

END;

