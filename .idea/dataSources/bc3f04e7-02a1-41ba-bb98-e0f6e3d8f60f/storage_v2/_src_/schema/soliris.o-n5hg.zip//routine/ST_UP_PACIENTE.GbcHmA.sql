create
    definer = soliris_ap@`%` procedure ST_UP_PACIENTE(IN v_id int, IN v_apellido varchar(100), IN v_nombre varchar(100),
                                                      IN v_fecha_nac date, IN v_sexo varchar(2),
                                                      IN v_telefono varchar(45), IN v_ciudad varchar(100),
                                                      IN v_pais_id int, IN v_mail varchar(100), IN v_patologia_id int,
                                                      IN v_sub_patologia_id int, IN v_os_id int,
                                                      IN v_usuario varchar(50), IN v_sub_estado_id varchar(50),
                                                      IN v_estado_id int, IN v_crm_id int)
    comment 'Actualizacion de paciente'
BEGIN

DECLARE c_usuario_mod_id INT;

declare exit handler FOR SQLWARNING
    begin
        SELECT 'ERROR: HA OCURRIDO UN ERROR AL ACTUALIZAR EL PACIENTE' AS mensaje;
    end;

SET c_usuario_mod_id = (SELECT u.id FROM usuario u WHERE v_usuario = u.username);





UPDATE paciente
	SET
		apellido=v_apellido,
		nombre=v_nombre,
		nombre_completo=CONCAT(v_apellido, ', ', v_nombre),
		fecha_nac=v_fecha_nac,
		sexo=v_sexo,
		telefono=v_telefono,
		ciudad=v_ciudad,
		pais_id=v_pais_id,
		mail=v_mail,
		patologia_id=v_patologia_id,
		sub_patologia_id=v_sub_patologia_id,
		os_id=v_os_id,
		c_gestar='',
		estado_id=v_estado_id,
		sub_estado_id=v_sub_estado_id,
		familia='SOL',
		fecha_modificacion=NOW(),
		usuario_mod_id=c_usuario_mod_id,
		crm_id=v_crm_id
	WHERE 
	  id = v_id;

SELECT 'ACTUALIZACION CORRECTA' AS mensaje;
	  
END;

