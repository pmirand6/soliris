create
    definer = soliris_ap@`%` function FU_UP_PAC(v_nombre varchar(200), v_estado varchar(45), v_sub_estado varchar(45),
                                                v_sexo varchar(2), v_c_gestar varchar(2), v_patologia varchar(250),
                                                v_fecha_nac date, v_telefono varchar(45), v_ciudad varchar(100),
                                                v_mail varchar(100), v_fecha_con date, v_usuario varchar(45), v_fv int,
                                                v_aprobado varchar(45), v_id int) returns longtext
BEGIN
DECLARE devolucion LONGTEXT;
	IF v_aprobado <> '' THEN
		UPDATE pacientes SET 
			aprobado = v_aprobado,
			fecha_aprobado = now()
		WHERE 
			id = v_id;
	END IF;

		UPDATE pacientes SET 
			Nombre = v_nombre,
	    estado = v_estado,
 	    sub_estado = v_sub_estado,
	    sexo = v_sexo,
	    c_gestar = v_c_gestar,
	    Patologia = v_patologia,
	    fecha_nac = v_fecha_nac,
	    telefono = v_telefono,
	    Ciudad = v_ciudad,
	    mail = v_mail,
	    Fecha_Con = v_fecha_con,
	    usuario = v_usuario,
	    fv = v_fv,
	    fecha_stamp = now()
		WHERE 
			id = v_id;



	IF (SELECT ROW_COUNT() > 0)  THEN
			SET devolucion = v_id;
	ELSE
			SET devolucion = 'ERROR NO_UPDATE';
	END IF;
	
	RETURN devolucion;

END;

