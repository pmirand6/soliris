create
    definer = soliris_ap@`%` function FU_UP_USR(v_usuario varchar(45), v_grupo varchar(45), v_familia varchar(3),
                                                v_mail varchar(90), v_estado varchar(45), v_id int) returns longtext
BEGIN
DECLARE devolucion LONGTEXT;
		UPDATE soliris_usuarios SET 
			usuario = v_usuario, 
			grupo = v_grupo, 
			familia = v_familia, 
			mail = v_mail,
			estado = v_estado
		WHERE 
			id = v_id;

	IF (SELECT ROW_COUNT() > 0)  THEN
			SET devolucion = v_id;
	ELSE
			SET devolucion = 'ERROR NO_UPDATE';
	END IF;
	
	RETURN devolucion;

END;

