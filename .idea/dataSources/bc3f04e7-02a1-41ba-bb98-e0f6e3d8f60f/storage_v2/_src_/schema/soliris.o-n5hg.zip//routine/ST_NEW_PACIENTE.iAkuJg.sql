create
    definer = soliris_ap@`%` procedure ST_NEW_PACIENTE(IN v_apellido varchar(100), IN v_nombre varchar(100),
                                                       IN v_fecha_nac date, IN v_sexo varchar(2),
                                                       IN v_telefono varchar(45), IN v_ciudad varchar(100),
                                                       IN v_pais_id int, IN v_mail varchar(100), IN v_patologia_id int,
                                                       IN v_sub_patologia_id int, IN v_os_id int,
                                                       IN v_usuario varchar(50), IN v_sub_estado_id varchar(50),
                                                       IN v_crm_id int) comment 'Creacion del nuevo paciente'
BEGIN

DECLARE c_usuario_id INT;
DECLARE c_sub_estado INT;

	 -- devolvemos el error que ya existe un paciente con la combinacion de apellido, nombre y fecha de nacimiento
    declare exit handler FOR 1062
    begin
        SELECT CONCAT('ERROR: Ya existe el paciente ', CONCAT(v_apellido, ', ', v_nombre), ' con fecha de nacimiento: ', v_fecha_nac) AS mensaje;
    end;
   

SET c_sub_estado = (SELECT id FROM `maestro_estado` WHERE `tipo` = 'sub_estado' AND valor = 'v_sub_estado');

SET c_usuario_id = (SELECT u.id FROM usuario u WHERE v_usuario = u.username);

INSERT INTO paciente
	(
		apellido,
		nombre,
		nombre_completo, 
		fecha_nac, 
		sexo, 
		telefono, 
		ciudad, 
		pais_id, 
		mail, 
		patologia_id, 
		sub_patologia_id, 
		os_id, 
		usuario_id, 		
		estado_id, 
		sub_estado_id, 
		fecha_creacion, 
		familia, 
		crm_id
		)
	VALUES 
	(
		v_apellido, 
		v_nombre, 
		CONCAT(v_apellido, ', ', nombre), 
		v_fecha_nac, 
		v_sexo, 
		v_telefono, 
		v_ciudad, 
		v_pais_id, 
		v_mail, 
		v_patologia_id, 
		v_sub_patologia_id, 
		v_os_id, 
		c_usuario_id, 
		7, 
		c_sub_estado, 
		NOW(), 
		'SOL', 
		v_crm_id
		);

SELECT LAST_INSERT_ID() AS mensaje;


END;

