create
    definer = soliris_ap@`%` function FU_SHOW_FECHA_CONS_PAC(v_id int) returns date
    comment 'Devuelve la fecha del consentimiento del paciente'
BEGIN

return (
SELECT 
--	date_format(d.fecha_documento, '%d/%m/%Y') as fconsen
	d.fecha_documento
FROM 
	rel_paciente_documentos r 
INNER JOIN 
	paciente p 
ON 
	r.paciente_id = v_id
INNER JOIN 
	documentos d 
ON 
	r.documento_id = d.id
WHERE 
	d.documentos_tipo_id = 1 -- ID del consentimiento informado de la tabla documentos_id
ORDER BY 
	r.id 
DESC LIMIT 0, 1); -- https://stackoverflow.com/questions/6881424/how-can-i-select-the-row-with-the-highest-id-in-mysql/20904650
				

				
END;

